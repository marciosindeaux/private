package com.example.sac;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("usuario")
public class AnyRestController {

    List<UserEntity> entityes = Arrays.asList(UserEntity.build());


    @GetMapping("{id}")
    public UserEntity getUsuario(@PathVariable("id") Long id) {
        return entityes.get(id.intValue());
    }

    @GetMapping
    public List<UserEntity> buscarTodos() {
        return entityes.stream().toList();
    }

    @GetMapping("{id}/nome")
    public String getNome(@PathVariable("id") Long id){
        return entityes.get(id.intValue()).getNome();
    }

    @GetMapping("{id}/idade")
    public String getidade(@PathVariable("id") Long id){
        return entityes.get(id.intValue()).getIdade();
    }

    @GetMapping("{id}/telefone")
    public String getTel(@PathVariable("id") Long id){
        return entityes.get(id.intValue()).getTelefone();
    }

    @PatchMapping("{id}/telefone")
    public UserEntity alterarTelefone(@PathVariable("id") Long id, @RequestBody UserEntity userEntity) {
        entityes.get(id.intValue()).setTelefone(userEntity.getTelefone());
        return entityes.get(id.intValue());
    }

    @PostMapping("cadastrar")
    public void cadastrar(@RequestBody UserEntity userEntity) {
        entityes.add(userEntity);
    }

    @DeleteMapping("{id}")
    public void deletar(@PathVariable("id") Long id) {
        entityes.remove(id.intValue());
    }

    @DeleteMapping
    public void deletarTodos() {
        entityes = new ArrayList<>();
    }
}
