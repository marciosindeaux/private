package com.example.demo.controller;

import com.example.demo.Entity.UserEntity;
import com.example.demo.feign.FeignUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("DEMO")
public class UserRestController {

    @Autowired
    private FeignUser fu;


    private String authToken = "Basic YWRtaW4yOjEyMzQ1Ng==";

    @GetMapping("buscar-usuarios")
    public List buscarUsuarios(){
        return fu.getUsuarios(authToken);
    }

    @GetMapping("deletar-usuarios")
    public String deletarUsuariosCadastrados() {
        try {
            fu.deletarTodos(authToken);
            return "Deu Certo";
        }catch (Exception E){
            return "Não Deu Certo";
        }
    }

    @GetMapping("cadastrar-dado-api-atual")
    public String cadastrarUsuarioDessaAPI() {
        try {
            fu.cadastrarNovo(authToken, UserEntity.build());
            return "Deu Certo";
        }catch (Exception E){
            E.printStackTrace();
            return "Não Deu Certo";
        }
    }




}
