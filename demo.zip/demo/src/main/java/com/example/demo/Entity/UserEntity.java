package com.example.demo.Entity;

public class UserEntity {

    private String nome;
    private String idade;
    private String telefone;


    public UserEntity(String nome, String idade, String telefone) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
    }

    public static UserEntity build() {
        return new UserEntity("Marcio", "23", "61981217133");
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
