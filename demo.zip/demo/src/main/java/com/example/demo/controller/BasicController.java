package com.example.demo.controller;

import com.example.demo.Entity.UserEntity;
import org.apache.catalina.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("user")
public class BasicController {

    @GetMapping("nome")
    public String getNome(){
        return UserEntity.build().getNome();
    }

    @GetMapping("idade")
    public String getidade(){
        return UserEntity.build().getIdade();
    }

    @GetMapping("telefone")
    public String getTel(){
        return UserEntity.build().getTelefone();
    }


}
