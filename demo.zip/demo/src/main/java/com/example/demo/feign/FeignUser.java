package com.example.demo.feign;

import com.example.demo.Entity.UserEntity;
import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "user-demo", url = "http://localhost:8082/usuario")
public interface FeignUser {

    @GetMapping()
    List getUsuarios(@RequestHeader("Authorization") String token);

    @PostMapping()
    void cadastrarNovo(@RequestHeader("Authorization") String token ,@RequestBody UserEntity userDTO);

    @DeleteMapping
    void deletarTodos(@RequestHeader("Authorization") String token);



}
